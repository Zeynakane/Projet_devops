<?php

$connect = mysqli_connect("databases","groupe3","groupe3","groupe3");
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
?>
